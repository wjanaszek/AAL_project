#ifndef FILEIOEXCEPTION_H
#define FILEIOEXCEPTION_H

/**
*   Wojciech Janaszek 273689 ISI
*   T11 - rozpl�tywanie odcink�w
*/

class FileIOException
{
    public:
        FileIOException();
        ~FileIOException();
};

#endif
