#include "WrongNumberOfElementsException.h"

/**
*   Wojciech Janaszek 273689 ISI
*   T11 - rozpl�tywanie odcink�w
*/

WrongNumberOfElementsException::WrongNumberOfElementsException()
{
    //ctor
}

WrongNumberOfElementsException::~WrongNumberOfElementsException()
{
    //dtor
}
