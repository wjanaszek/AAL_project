#include "FileIOException.h"

/**
*   Wojciech Janaszek 273689 ISI
*   T11 - rozpl�tywanie odcink�w
*/

FileIOException::FileIOException()
{
    //ctor
}

FileIOException::~FileIOException()
{
    //dtor
}
