#include "Sweeper.h"
#include <climits>
#include <iostream>

/**
*   Wojciech Janaszek 273689 ISI
*   T11 - rozpl�tywanie odcink�w
*/

using namespace std;

Sweeper::Sweeper()
{
    Point2D * left = new Point2D(0, INT_MAX);
    Point2D * right = new Point2D(0, INT_MIN);
    sweeperLine = new Segment(*left, *right, -1);
    delete left;
    delete right;
}

Sweeper::~Sweeper()
{
    delete sweeperLine;
}

void Sweeper::push(Segment * s)
{
    /*Point2D * intersectionPoint;
    Point2D * intersectionPoint2;

    if(container.size() == 0){
        container.push_back(s);
        return;
    }

    moveSweeper(s->getLeft().getX());
    intersectionPoint = Segment::getIntersectionPoint(*s, *sweeperLine);

    Segment * tmp;
    /*for(int i = container.size(); i >= 0; i--){
        //cout << " i = " << i << endl;
        //tmp = new Segment(container[i]->getLeft(), container[i]->getRight(), container[i]->N);
        //tmp->getLeft().setX(sweeperLine->getLeft().getX());
        /*intersectionPoint2 = Segment::getIntersectionPoint(*container[i], *sweeperLine);
        cout << "inP1 = " << intersectionPoint->getY() << endl;
        cout << "inP2 = " << intersectionPoint2->getY() << endl;
        if(intersectionPoint2->getY() >= intersectionPoint->getY()){
            container.insert(container.begin() + i, s);
            delete intersectionPoint;
            delete intersectionPoint2;
            return;
        }
        /*if(s->getLeft().getY() >= container[i]->getLeft().getY()){
            container.insert(container.begin() + i, s);
            return;
        }*/
    //}
    //cout << "Zle dodanie?" << endl;
    container.push_back(s);
}

void Sweeper::remove(Segment * s)
{
    int index = -1;
    for(int i = 0; i < container.size(); i++){
        if(s->getLeft().getX() == container[i]->getLeft().getX() && s->getLeft().getY() == container[i]->getLeft().getY()
           && s->getRight().getX() == container[i]->getRight().getX() && s->getRight().getY() == container[i]->getRight().getY()
           && s->N == container[i]->N){
            index = i;
            break;
        }
    }
    if(index != -1){
        container.erase(container.begin() + index);
    }
    else {
        cout << "Blad usuwania!!!" << endl;
    }
}

Segment * Sweeper::getElementAt(int index)
{
    return container.at(index);
}

/*Segment & Sweeper::getElementAt(int index)
{

    return container[index];
}*/

int Sweeper::getSize()
{
    return container.size();
}

// "ABOVE"
Segment * Sweeper::previous(Segment * s)
{
    Segment * tmp;
    Point2D * intersectionPoint, * intersectionPoint2;
    moveSweeper(s->getLeft().getX());
    intersectionPoint = Segment::getIntersectionPoint(*s, *sweeperLine);
    for(int i = 0; i < container.size(); i++){

        //tmp = new Segment(container[i]->getLeft(), container[i]->getRight(), container[i]->N);
        //tmp->getLeft().setX(sweeperLine->getLeft().getX());
        intersectionPoint2 = Segment::getIntersectionPoint(*container[i], *sweeperLine);
        if(intersectionPoint2->getY() >= intersectionPoint->getY() /*&& intersectionPoint2->groupNumber != intersectionPoint->groupNumber*/){
            delete intersectionPoint;
            delete intersectionPoint2;
            return container[i];
        }
        /*if(s->getLeft().getY() <= container[i]->getLeft().getY()
           && s->getRight().getY() <= container[i]->getLeft().getY()
           && s->N != container[i]->N){
            return container[i];
        }*/
    }
    return NULL;
}

// "BELOW"
Segment * Sweeper::next(Segment * s)
{
    Segment * tmp;
    Point2D * intersectionPoint, * intersectionPoint2;
    moveSweeper(s->getLeft().getX());
    intersectionPoint = Segment::getIntersectionPoint(*s, *sweeperLine);
    for(int i = 0; i < container.size(); i++){
        //tmp = new Segment(container[i]->getLeft(), container[i]->getRight(), container[i]->N);
        //tmp->getLeft().setX(sweeperLine->getLeft().getX());
        intersectionPoint2 = Segment::getIntersectionPoint(*container[i], *sweeperLine);
        if(intersectionPoint2->getY() <= intersectionPoint->getY() /*&& intersectionPoint2->groupNumber != intersectionPoint->groupNumber*/){
            delete intersectionPoint;
            delete intersectionPoint2;
            return container[i];
        }
        /*if(s->getLeft().getY() >= container[i]->getLeft().getY()
           && s->getRight().getY() >= container[i]->getLeft().getY()
           && s->N != container[i]->N){
            return container[i];
        }*/
    }
    return NULL;
}

void Sweeper::moveSweeper(int val)
{
    int prevVal = sweeperLine->getLeft().getX();
    sweeperLine->getLeft().setX(prevVal + val);
    sweeperLine->getRight().setX(prevVal + val);
}
