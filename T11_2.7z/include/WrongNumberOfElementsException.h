#ifndef WRONGNUMBEROFELEMENTSEXCEPTION_H
#define WRONGNUMBEROFELEMENTSEXCEPTION_H

/**
*   Wojciech Janaszek 273689 ISI
*   T11 - rozpl�tywanie odcink�w
*/

class WrongNumberOfElementsException
{
    public:
        WrongNumberOfElementsException();
        ~WrongNumberOfElementsException();
};

#endif // WRONGNUMBEROFELEMENTSEXCEPTION_H
