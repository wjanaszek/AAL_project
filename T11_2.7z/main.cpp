#include <iostream>
#include <string>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <sstream>
#include <ctime>
#include "DataService.h"
#include "FileIOException.h"
#include "Point2D.h"
#include "Algorithms.h"
#include "ezdib.h"
#include "SetOfSegments.h"
#include "Segment.h"

#define RADIUS 6
#define BLUE 0x0000ff
#define RED 0xff0000
#define WHITE 0xffffff
#define BLACK 0x000000
#define MAX_VERT_COUNT 7

/**
*   Wojciech Janaszek 273689 ISI
*   T11 - rozpl�tywanie odcink�w
*/

using namespace std;

typedef vector<Point2D> points;

// Image for brutal force algorithm
HEZDIMAGE hDib_BF;
// Image for algorithm
HEZDIMAGE hDib_CN;
// Vector of input points
vector<points> input;

// Forward functions definitions:
bool checkParam(string input, char paramName);
int getParam(string input, char paramName);
void secondTypeWithParametrization(int argc, char ** argv, char * arg, int * N, int * seed);
void secondTypeWithoutParametrization(int argc, char ** argv, char * arg, int * N);
void brutalForce(vector<points> v);
void optAlgorithm(vector<points> v);
char * getCurrentDateToString();

// Function to draw to specified imagefile
void drawToFile(HEZDIMAGE * image, SetOfSegments * s);

// Main
int main(int argc, char ** argv) {
    // Input arguments
	char *arg1, *arg2, *arg3;
	int seed;
	int N;
	string tmp;
	DataService ds;

    srand(time(NULL));

    // For polish signs
    setlocale(LC_ALL,"");

	// Different parameters service
	if (argc > 1) {
		arg1 = argv[1];
		// pierwszy tryb - wczytanie danych z pliku lub z klawiatury
		// wczytanie danych z klawiatury:
		if (strcmp(arg1, "-1k") == 0) {
			input = ds.readFromKeyboard();			// wczytaj dane
			arg2 = argv[2];
			int alg_type = stoi(string(arg2));
			if(input[0].size() < MAX_VERT_COUNT && alg_type == 0){
                brutalForce(input);
                return 0;
			}
			else if(input[0].size() >= MAX_VERT_COUNT && alg_type == 0){
                    cout << "Rozmiar problemu przekracza ograniczenia dla tego algorytmu. Problem dla zadanej wielkosci zostanie rozwiazany przy pomocy algorytmu nr 2" << endl;
            }
			optAlgorithm(input);
			return 0;
		}
		// wczytanie danych z pliku (konieczne podane nazwy pliku jako kolejny parametr):
		else if (strcmp(arg1, "-1f") == 0) {
			if (argc > 1) {
				arg2 = argv[2];
				arg3 = argv[3];
				int alg_type = stoi(string(arg3));
				input = ds.readFromFile(string(arg2));
				if(input[0].size() < MAX_VERT_COUNT && alg_type == 0){
                    brutalForce(input);
                    return 0;
				}
				else if(input[0].size() >= MAX_VERT_COUNT && alg_type == 0){
                    cout << "Rozmiar problemu przekracza ograniczenia dla tego algorytmu. Problem dla zadanej wielkosci zostanie rozwiazany przy pomocy algorytmu nr 2" << endl;
				}
				optAlgorithm(input);
				return 0;
			}
			else {
				cout << "Brak nazwy pliku do wczytania!" << endl;
				exit(1);
			}
		}
		// drugi tryb - wygenerowanie potrzebnych danych losowo, z mozliwoscia parametryzacji losowosci
		// z parametryzacja:
		else if (strcmp(arg1, "-2g") == 0) {
            arg3 = argv[4];
            int alg_type = stoi(string(arg3));
			secondTypeWithParametrization(argc, argv, arg1, &N, &seed);
			input = ds.generateData(N, seed);			// wygeneruj dane
			if(input[0].size() < MAX_VERT_COUNT && alg_type == 0){
                brutalForce(input);
                return 0;
            }
            else if(input[0].size() >= MAX_VERT_COUNT && alg_type == 0){
                cout << "Rozmiar problemu przekracza ograniczenia dla tego algorytmu. Problem dla zadanej wielkosci zostanie rozwiazany przy pomocy algorytmu nr 2" << endl;
            }
            optAlgorithm(input);
            return 0;
		}
		// bez parametryzacji:
		else if (strcmp(arg1, "-2gwout") == 0) {
			secondTypeWithoutParametrization(argc, argv, arg1, &N);
            arg3 = argv[3];
            int alg_type = stoi(string(arg3));
			input = ds.generateData(N);
			if(input[0].size() < MAX_VERT_COUNT && alg_type == 0){
                brutalForce(input);
                return 0;
            }
            else if(input[0].size() >= MAX_VERT_COUNT && alg_type == 0){
                cout << "Rozmiar problemu przekracza ograniczenia dla tego algorytmu. Problem dla zadanej wielkosci zostanie rozwiazany przy pomocy algorytmu nr 2" << endl;
            }
            optAlgorithm(input);
            return 0;
		}
		// trzeci tryb - wykonanie z generacja danych, pomiarem czasu i prezentacja wynikow
		// z parametryzacja:
		else if (strcmp(arg1, "-3g") == 0) {
			secondTypeWithParametrization(argc, argv, arg1, &N, &seed);
			arg3 = argv[4];
			int alg_type = stoi(string(arg3));
			input = ds.generateData(N, seed);
			if(input[0].size() < MAX_VERT_COUNT && alg_type == 0){
                brutalForce(input);
                return 0;
            }
            else if(input[0].size() >= MAX_VERT_COUNT && alg_type == 0){
                cout << "Rozmiar problemu przekracza ograniczenia dla tego algorytmu. Problem dla zadanej wielkosci zostanie rozwiazany przy pomocy algorytmu nr 2" << endl;
            }
            optAlgorithm(input);
            return 0;
		}
		// bez parametryzacji:
		else if (strcmp(arg1, "-3gwout") == 0) {
			secondTypeWithoutParametrization(argc, argv, arg1, &N);
			input = ds.generateData(N);
			arg3 = argv[3];
			int alg_type;
			if(arg3 != nullptr){
                alg_type = stoi(string(arg3));
			}
			else {
                cout << "Nie wybrano zadnego algorytmu!" << endl;
                exit(1);
			}
			if(input[0].size() < MAX_VERT_COUNT && alg_type == 0){
                brutalForce(input);
                return 0;
            }
            else if(input[0].size() >= MAX_VERT_COUNT && alg_type == 0){
                cout << "Rozmiar problemu przekracza ograniczenia dla tego algorytmu. Problem dla zadanej wielkosci zostanie rozwiazany przy pomocy algorytmu nr 2" << endl;
            }
            optAlgorithm(input);
            return 0;
		}
		else {
			cout << "Niepoprawne polecenie. Instrukcja znajduje si� w pliku readme.txt" << endl;
			exit(1);
		}
	}
	else {
        cout << "Niepoprawne polecenie. Instrukcja znajduje si� w pliku readme.txt" << endl;
        exit(1);
	}
	// TEST ONLY:
    //generateOneSubsetOfSegments();

	return 0;
}

bool checkParam(string input, char paramName) {
	bool wasParamName = false;
	bool wasNumbers = true;
	if (input.length() <= 1) {
		return false;
	}
	if (input.c_str()[0] != '-') {
		return false;
	}
	if (input.c_str()[1] != paramName) {
		return false;
	}
	else {
		wasParamName = true;
	}
	if (input.length() <= 2) {
		return false;
	}
	for (int i = 2; i < input.length(); i++) {
		if (isdigit(input.c_str()[i]) == 0) {
			wasNumbers = false;
			break;
		}
	}
	return wasParamName && wasNumbers;
}

int getParam(string input, char paramName) {
	input.erase(0, 2);
	int result = atoi(input.c_str());
	return result;
}

void secondTypeWithParametrization(int argc, char ** argv, char * arg1, int * N, int * seed) {
	char * arg2, * arg3;
	if (argc > 2) {
		arg2 = argv[2];
		if (checkParam(string(arg2), 'N')) {
			*N = getParam(string(arg2), 'N');
			if (argc > 3) {
				arg3 = argv[3];
				if (checkParam(string(arg3), 'S')) {
					*seed = getParam(string(arg3), 'S');
				}
				else {
					cout << "Podano nieprawidlowy parametr: seed \"-S<value>\"! Moze chodzi o brak cyfr?" << endl;
					exit(1);
				}
			}
			else {
				cout << "Nie podano parametru: seed \"-S<value>\"!" << endl;
				exit(1);
			}
		}
		else {
			cout << "Podano nieprawidlowy parametr: N \"-N<value>\"! Moze chodzi o brak cyfr?" << endl;
			exit(1);
		}
	}
	else {
		cout << "Nie podano parametru: N \"-N<value>\"!" << endl;
		exit(1);
	}
}

void secondTypeWithoutParametrization(int argc, char ** argv, char * arg1, int * N) {
	char * arg2;
	if (argc > 2) {
		arg2 = argv[2];
		if (checkParam(string(arg2), 'N')) {
			*N = getParam(string(arg2), 'N');
		}
		else {
			cout << "Podano nieprawidlowy parametr: N \"-N<value>\"! Moze chodzi o brak cyfr?" << endl;
			exit(1);
		}
	}
	else {
		cout << "Nie podano parametru: N \"-N<value>\"!" << endl;
		exit(1);
	}
}

char * getCurrentDateToString() {
    time_t rawtime;
    struct tm * timeinfo;
    char buffer[80];

    time (&rawtime);
    timeinfo = localtime(&rawtime);

    strftime(buffer,sizeof(buffer),"%d-%m-%Y %I:%M:%S",timeinfo);
    std::string str(buffer);
    char *result = new char[15];
    int j = 0;
    for(int i = 0; i < str.size(); i++){
        if(isdigit(buffer[i])){
            result[j] = buffer[i];
            j++;
        }
    }
    result[14] = '\0';
    return result;
}

void brutalForce(vector<points> v)
{
    int inputSize = v[0].size();
    const clock_t begin_time = clock();
    SetOfSegments * bf;
    char imgFileName[22];
    char *currDate = getCurrentDateToString();
    imgFileName[0] = 'b';
    imgFileName[1] = 'f';
    imgFileName[2] = '_';
    imgFileName[3] = currDate[0];
    imgFileName[4] = currDate[1];
    imgFileName[5] = currDate[2];
    imgFileName[6] = currDate[3];
    imgFileName[7] = currDate[4];
    imgFileName[8] = currDate[5];
    imgFileName[9] = currDate[6];
    imgFileName[10] = currDate[7];
    imgFileName[11] = currDate[8];
    imgFileName[12] = currDate[9];
    imgFileName[13] = currDate[10];
    imgFileName[14] = currDate[11];
    imgFileName[15] = currDate[12];
    imgFileName[16] = currDate[13];
    imgFileName[17] = '.';
    imgFileName[18] = 'b';
    imgFileName[19] = 'm';
    imgFileName[20] = 'p';
    imgFileName[21] = '\0';

    delete currDate;

    hDib_BF = ezd_create( 1920, -1080, 24, 0 );
    // Fill in the background with a dark gray color
    ezd_fill( hDib_BF, 0x606060 );
    bf = Algorithms::executeBrutalForce(input);
    drawToFile(&hDib_BF, bf);
    ezd_save(hDib_BF, imgFileName);
    ezd_destroy(hDib_BF);

    cout << "Algorytm nr 1 wykonal sie w czasie " << float( clock () - begin_time ) /  CLOCKS_PER_SEC << " dla N = " << inputSize << endl;
    cout << "Efekt pracy zapisano do pliku: " << imgFileName << endl;
    cout << "--------------------------------------------------------" << endl;
}

void optAlgorithm(vector<points> v)
{
    const clock_t begin_time = clock();
    SetOfSegments * opt;
    char imgFileName[22];
    char *currDate = getCurrentDateToString();
    int inputSize = v[0].size();
    /*stringstream ss;
    string tmp;

    salt = rand() % 100;
    ss << salt;
    tmp = ss.str();
    char * tmpChars = const_cast<char*>(tmp.c_str());
    if(salt < 10){
        tmpChars[1] = '_';
    }*/
    imgFileName[0] = 'o';
    imgFileName[1] = 'p';
    imgFileName[2] = '_';
    imgFileName[3] = currDate[0];
    imgFileName[4] = currDate[1];
    imgFileName[5] = currDate[2];
    imgFileName[6] = currDate[3];
    imgFileName[7] = currDate[4];
    imgFileName[8] = currDate[5];
    imgFileName[9] = currDate[6];
    imgFileName[10] = currDate[7];
    imgFileName[11] = currDate[8];
    imgFileName[12] = currDate[9];
    imgFileName[13] = currDate[10];
    imgFileName[14] = currDate[11];
    imgFileName[15] = currDate[12];
    imgFileName[16] = currDate[13];
    imgFileName[17] = '.';
    imgFileName[18] = 'b';
    imgFileName[19] = 'm';
    imgFileName[20] = 'p';
    imgFileName[21] = '\0';

    delete currDate;

    hDib_CN = ezd_create( 1920, -1080, 24, 0 );
     // Fill in the background with a dark gray color
    ezd_fill( hDib_CN, 0x606060 );
    opt = Algorithms::executeAlgorithm(input);
    drawToFile(&hDib_CN, opt);
    ezd_save(hDib_CN, imgFileName);
    ezd_destroy(hDib_CN);

    cout << "Algorytm nr 2 wykonal sie w czasie " << float( clock () - begin_time ) /  CLOCKS_PER_SEC << " dla N = " << inputSize << endl;
    cout << "Efekt pracy zapisano do pliku: " << imgFileName << endl;
}


void drawToFile(HEZDIMAGE * image, SetOfSegments * s)
{
    //cout << "DRAW_TO_FILE segments = " << s->getSize() << endl;
    for(int i = 0; i < s->getSize(); i++)
    {
        //cout << "czerwony: (" << s->getSegments()[i]->getLeft().getX() << ", " << s->getSegments()[i]->getLeft().getY() << ")" << endl;
        ezd_circle(*image, s->getSegments()[i]->getLeft().getX(),
                         s->getSegments()[i]->getLeft().getY(),
                         RADIUS, RED);
        //cout << "niebieski: (" << s->getSegments()[i]->getRight().getX() << ", " << s->getSegments()[i]->getRight().getY() << ")" << endl;
        ezd_circle(*image, s->getSegments()[i]->getRight().getX(),
                         s->getSegments()[i]->getRight().getY(),
                         RADIUS, BLUE);
        ezd_line(*image, s->getSegments()[i]->getLeft().getX(), s->getSegments()[i]->getLeft().getY(),
                       s->getSegments()[i]->getRight().getX(), s->getSegments()[i]->getRight().getY(), WHITE);
    }
}
